<?php

namespace SevenTag\Plugin\TestBundle;

use SevenTag\Api\AppBundle\Plugin\PluginAwareBundle;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class SevenTagPluginTestBundle extends PluginAwareBundle
{
}
