<?php

namespace SevenTag\Plugin\TestBundle\Listener;

use SevenTag\Api\VariableBundle\Event\LoadVariableTypeEvent;
use SevenTag\Component\Variable\Model\VariableType;

class AddNewVariableListener
{
    public function onRun(LoadVariableTypeEvent $event)
    {
        $event->getVariableTypeCollection()->set(
            'newVariableType',
            new VariableType('newVariableType', 'newVariableType', 'newVariableType', 'New variable type')
        );
    }
}
