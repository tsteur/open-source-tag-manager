var config = function ($collectorProvider) {
    $collectorProvider
        .add('newVariableType', function () {
            return Math.random();
        });
};
config.$inject = [
    '$collectorProvider'
];

sevenTag.config(config);