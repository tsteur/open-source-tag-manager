(function () {
    'use strict';

    var MODULE_NAME = 'admin.application';

    angular
        .module(MODULE_NAME)
        .run([

            'clearcode.tm.variable.$variableForm',

            function ($variableFormProvider) {

                $variableFormProvider
                    .addType('newVariableType', {
                        templateUrl: '../bundles/seventagplugintest/html/newVariableType.html'
                    });

            }
        ])
}());
